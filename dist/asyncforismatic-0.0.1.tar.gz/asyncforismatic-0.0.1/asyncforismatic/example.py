import pyforismatic
import asyncio

# getting sync quote on russian
print(pyforismatic.quote(lang='ru')) 

# getting async quote with default language (english)
async def example():
    return await pyforismatic.async_quote()
print(asyncio.run(example()))